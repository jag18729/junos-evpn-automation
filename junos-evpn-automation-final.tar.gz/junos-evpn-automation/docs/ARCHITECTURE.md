# Architecture Guide

## Network Design Principles

### 1. Underlay Network (Physical)

The underlay provides IP connectivity between all fabric devices using eBGP.

```
              Spine Layer (Route Reflectors)
                    AS 65000-65099
                         │
                    eBGP │ /31 Links
                         │
              Leaf Layer (VTEPs)
                    AS 65100-65199
```

**Key Design Decisions:**

- **eBGP between spine/leaf** - Fast convergence, loop-free by design
- **/31 point-to-point links** - Efficient IP usage
- **BFD enabled** - Sub-second failure detection
- **ECMP load balancing** - All paths active

### 2. Overlay Network (Virtual)

EVPN provides the control plane for VXLAN tunnels.

```
     ┌──────────────────────────────────┐
     │         EVPN Control Plane        │
     │    (MP-BGP with EVPN NLRI)       │
     └──────────────────────────────────┘
                    │
     ┌──────────────────────────────────┐
     │         VXLAN Data Plane         │
     │     (UDP Port 4789 Tunnels)      │
     └──────────────────────────────────┘
```

**EVPN Route Types Used:**

| Type | Purpose |
|------|---------|
| Type 2 | MAC/IP Advertisement |
| Type 3 | Inclusive Multicast |
| Type 5 | IP Prefix Route |

### 3. Zero Trust Segmentation

Each zone is isolated by default with explicit allow rules.

```
┌─────────────┐     ❌ Denied      ┌─────────────┐
│ Production  │ ←───────────────→ │ Development │
│ VNI 10100   │                   │ VNI 10200   │
└─────────────┘                   └─────────────┘
       ↑                                 ↑
       │ ❌ Denied              Denied ❌ │
       ↓                                 ↓
┌─────────────┐                   ┌─────────────┐
│     DMZ     │ ←───────────────→ │   Guest     │
│ VNI 10300   │     ❌ Denied      │ VNI 10400   │
└─────────────┘                   └─────────────┘
```

## Scalability Considerations

### IP Address Planning

```yaml
Underlay:
  Loopbacks: 192.168.0.0/24     # /32 per device, supports 254 devices
  P2P Links: 10.0.0.0/16        # /31 per link, supports 32k links
  
Overlay:
  VNI Range: 10000-19999         # 10k VNIs available
  Tenant Subnets: 172.16.0.0/12  # Private IP space for tenants
```

### Growth Planning

| Component | Initial | Maximum | Notes |
|-----------|---------|---------|-------|
| Spines | 2 | 8 | Limited by leaf port density |
| Leafs | 4 | 128 | Limited by spine port density |
| VNIs | 10 | 10,000 | Hardware dependent |
| MACs | 1k | 256k | Per leaf switch |

## High Availability

### Control Plane HA

- **Dual Route Reflectors** - Both spines act as RRs
- **BGP Multipath** - Load balance across all paths
- **Graceful Restart** - Hitless upgrades

### Data Plane HA

- **Multihoming (ESI)** - Servers dual-connected to leaf pairs
- **Anycast Gateway** - Same gateway IP/MAC on all leafs
- **Fast convergence** - BFD + tuned timers

## Security Architecture

### Defense in Depth

```
Layer 1: Physical Security
         └── Secure data center access
         
Layer 2: Network Segmentation  
         └── VXLAN/VNI isolation
         
Layer 3: Access Control
         └── RBAC + SSH hardening
         
Layer 4: Monitoring
         └── Audit logs + SIEM integration
```

### RBAC Model

```
┌──────────────┐
│ Network Admin│ ──── Full configuration access
└──────────────┘
        │
┌──────────────┐
│   Operator   │ ──── Operational commands only
└──────────────┘
        │
┌──────────────┐
│    Viewer    │ ──── Read-only access
└──────────────┘
```

## Automation Workflow

```
     Start
       │
       ▼
┌─────────────┐
│Generate IPs │ ──── calculate_underlay_ips()
└─────────────┘
       │
       ▼
┌─────────────┐
│Create VLANs │ ──── generate_vxlan_config()
└─────────────┘
       │
       ▼
┌─────────────┐
│Render Configs│ ──── Jinja2 templates
└─────────────┘
       │
       ▼
┌─────────────┐
│Deploy via ZTP│ ──── DHCP + HTTP server
└─────────────┘
       │
       ▼
┌─────────────┐
│  Validate   │ ──── Health checks
└─────────────┘
       │
       ▼
      End
```

## Configuration Management

### GitOps Workflow

```
Developer → Git Push → CI/CD Pipeline → Validation → Production
              │                            │
              └── Version Control          └── Automated Testing
```

### Change Management

1. **Development** - Test in lab environment
2. **Staging** - Validate in pre-production
3. **Production** - Canary deployment
4. **Rollback** - Automated if validation fails

## Performance Optimization

### BGP Timers

```junos
protocols {
    bgp {
        group UNDERLAY {
            hold-time 9;
            minimum-hold-time 3;
            bfd-liveness-detection {
                minimum-interval 100;
                multiplier 3;
            }
        }
    }
}
```

### VXLAN Optimization

- **Jumbo frames (MTU 9216)** - Reduce fragmentation
- **Hardware offload** - Use ASIC for VXLAN encap/decap
- **Load balancing** - Hash on inner headers

## Monitoring Strategy

### Key Metrics

| Metric | Warning | Critical |
|--------|---------|----------|
| BGP Sessions | <100% up | Any down |
| VXLAN Tunnels | <100% up | Any down |
| MAC Count | >80% limit | >90% limit |
| CPU Usage | >70% | >85% |
| Memory Usage | >80% | >90% |

### Health Check Intervals

- **Real-time** - BGP/BFD status
- **5 minutes** - Interface statistics
- **15 minutes** - MAC table size
- **1 hour** - Configuration backup
- **Daily** - Full validation report
