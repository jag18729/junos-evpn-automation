# Deployment Guide

## Pre-Deployment Checklist

### ✅ Hardware Requirements

- [ ] Juniper QFX5120/QFX5100 series switches
- [ ] Minimum 2 spine switches
- [ ] Minimum 2 leaf switches per rack
- [ ] Out-of-band management network
- [ ] Console server for initial access

### ✅ Software Requirements

- [ ] Junos 18.1R1 or later
- [ ] Python 3.8+ on management server
- [ ] DHCP server for ZTP
- [ ] HTTP server for file distribution
- [ ] Git for version control

### ✅ Network Requirements

- [ ] Management network planned (e.g., 192.168.1.0/24)
- [ ] Underlay network planned (e.g., 10.0.0.0/16)
- [ ] Overlay VNI range defined (e.g., 10000-19999)
- [ ] ASN numbers allocated
- [ ] IP address scheme documented

---

## Step-by-Step Deployment

### Phase 1: Preparation (Day 1)

#### 1.1 Setup Management Server

```bash
# Install required packages
sudo apt-get update
sudo apt-get install -y python3-pip git isc-dhcp-server apache2

# Clone automation repository
git clone https://github.com/jag18729/junos-evpn-automation.git
cd junos-evpn-automation

# Setup environment
./setup.sh
source venv/bin/activate
```

#### 1.2 Configure DHCP Server

```bash
# Edit /etc/dhcp/dhcpd.conf
sudo cp ztp/dhcpd.conf /etc/dhcp/dhcpd.conf
sudo systemctl restart isc-dhcp-server
```

#### 1.3 Prepare Junos Images

```bash
# Download Junos images from Juniper support site
# Place in ztp/images/
wget -O ztp/images/junos-qfx-21.4R3.tgz <download-url>
```

### Phase 2: Configuration Generation (Day 1)

#### 2.1 Customize Fabric Configuration

Edit `configs/fabric.yaml`:

```yaml
fabric:
  name: "PROD-DC1"
  asn: 65000
  
spines:
  count: 2
  model: "QFX5120-32C"
  
leafs:
  count: 4
  model: "QFX5120-48Y"
```

#### 2.2 Generate Device Configurations

```bash
# Generate all configurations
python scripts/configure_fabric.py --config configs/fabric.yaml

# Review generated configs
ls -la configs/generated/
```

#### 2.3 Validate Configuration Syntax

```bash
# Use Juniper's config checker
for file in configs/generated/*.conf; do
    echo "Checking $file"
    # Add validation logic here
done
```

### Phase 3: Zero Touch Provisioning (Day 2)

#### 3.1 Prepare ZTP Server

```bash
# Deploy ZTP configuration
python scripts/deploy_ztp.py --subnet 192.168.1.0/24

# Start HTTP server
cd ztp && python3 server.py &
```

#### 3.2 Cable Devices

Physical cabling layout:

```
Spine1 ─┬─ et-0/0/0 ←→ et-0/0/48 ─ Leaf1
        ├─ et-0/0/1 ←→ et-0/0/48 ─ Leaf2
        ├─ et-0/0/2 ←→ et-0/0/48 ─ Leaf3
        └─ et-0/0/3 ←→ et-0/0/48 ─ Leaf4

Spine2 ─┬─ et-0/0/0 ←→ et-0/0/49 ─ Leaf1
        ├─ et-0/0/1 ←→ et-0/0/49 ─ Leaf2
        ├─ et-0/0/2 ←→ et-0/0/49 ─ Leaf3
        └─ et-0/0/3 ←→ et-0/0/49 ─ Leaf4
```

#### 3.3 Power On Devices

```bash
# Monitor DHCP requests
sudo tail -f /var/log/syslog | grep DHCP

# Monitor ZTP progress
tail -f ztp/logs/ztp.log
```

### Phase 4: Initial Validation (Day 2)

#### 4.1 Verify Device Access

```bash
# Test connectivity
python scripts/connect_devices.py \
    -h 192.168.1.11 \
    -h 192.168.1.12 \
    -h 192.168.1.21 \
    -h 192.168.1.22
```

#### 4.2 Check BGP Status

```bash
# Run validation
python scripts/validate_fabric.py \
    -d 192.168.1.11 \
    -d 192.168.1.21 \
    -u admin
```

### Phase 5: RBAC Configuration (Day 3)

#### 5.1 Create User Accounts

```bash
# Create admin user
python scripts/manage_rbac.py \
    --action create \
    --username netadmin \
    --role network_admin

# Create operator user
python scripts/manage_rbac.py \
    --action create \
    --username netops \
    --role network_operator
```

#### 5.2 Deploy RBAC Policies

```bash
# Deploy to all devices
for device in 192.168.1.{11,12,21,22}; do
    python scripts/manage_rbac.py \
        --action deploy \
        --device $device
done
```

### Phase 6: Service Activation (Day 3)

#### 6.1 Create Test VLANs

```junos
# On leaf switches
set vlans TEST_VLAN vlan-id 100
set vlans TEST_VLAN vxlan vni 10100
commit
```

#### 6.2 Verify VXLAN Tunnels

```bash
# Check VTEP status
ssh admin@192.168.1.21 "show ethernet-switching vxlan-tunnel-end-point remote"
```

#### 6.3 Test End-to-End Connectivity

```bash
# From server connected to Leaf1
ping 172.16.0.100  # Server on Leaf2
```

---

## Production Cutover

### Pre-Cutover Tasks

- [ ] Full configuration backup
- [ ] Maintenance window scheduled
- [ ] Rollback plan documented
- [ ] Team notifications sent
- [ ] Monitoring alerts configured

### Cutover Steps

1. **Final validation run**
   ```bash
   python scripts/validate_fabric.py --all --report pre_cutover.txt
   ```

2. **Migrate production traffic**
   ```bash
   # Move VLANs one at a time
   # Monitor for issues
   ```

3. **Post-migration validation**
   ```bash
   python scripts/validate_fabric.py --all --report post_cutover.txt
   ```

### Rollback Procedure

If issues occur:

1. **Revert configurations**
   ```bash
   # Load previous configs from backup
   python scripts/restore_configs.py --backup-dir backups/pre_cutover/
   ```

2. **Verify rollback**
   ```bash
   python scripts/validate_fabric.py --all
   ```

---

## Post-Deployment

### Day 1 Operations

- Monitor BGP sessions
- Check EVPN database growth
- Verify MAC learning
- Review system logs

### Week 1 Tasks

- [ ] Performance baseline established
- [ ] Backup procedures tested
- [ ] Documentation updated
- [ ] Team training completed

### Month 1 Review

- [ ] Capacity planning review
- [ ] Security audit
- [ ] Performance optimization
- [ ] Automation improvements

---

## Troubleshooting Guide

### Common Issues

#### Issue: BGP Session Not Establishing

```bash
# Check underlay connectivity
ping 192.168.0.2 source 192.168.0.1

# Verify BGP configuration
show configuration protocols bgp

# Check logs
show log messages | match BGP
```

#### Issue: VXLAN Tunnel Not Forming

```bash
# Verify VTEP configuration
show configuration switch-options

# Check EVPN status
show evpn database

# Verify VNI mapping
show vlans extensive
```

#### Issue: No MAC Learning

```bash
# Check EVPN routes
show route table bgp.evpn.0

# Verify MAC table
show ethernet-switching table

# Check interface status
show interfaces terse
```

---

## Support Contacts

- **Juniper TAC**: 1-888-314-JTAC
- **Internal Team**: netops@company.com
- **Automation Support**: automation@company.com
