# API Documentation

## Script Reference

### configure_fabric.py

Generate device configurations from YAML template.

**Usage:**
```bash
python scripts/configure_fabric.py [OPTIONS]
```

**Options:**
- `--config PATH` - Fabric configuration file (default: configs/fabric.yaml)
- `--output PATH` - Output directory for configs (default: configs/generated)
- `--dry-run` - Preview without saving files

**Example:**
```bash
python scripts/configure_fabric.py --config configs/fabric.yaml --dry-run
```

**Configuration Schema:**
```yaml
fabric:
  name: string          # Fabric identifier
  asn: integer         # Base ASN number
  underlay:
    ipv4_pool: string  # Underlay IP range (CIDR)
    loopback_pool: string # Loopback IP range (CIDR)
    mtu: integer       # Interface MTU
  overlay:
    route_reflector: list # RR IP addresses
    vni_range:
      start: integer   # Starting VNI
      end: integer     # Ending VNI
```

---

### deploy_ztp.py

Deploy Zero Touch Provisioning server.

**Usage:**
```bash
python scripts/deploy_ztp.py [OPTIONS]
```

**Options:**
- `--subnet STRING` - Management subnet (default: 192.168.1.0/24)
- `--config PATH` - Fabric configuration file
- `--start-server` - Start HTTP server immediately

**Example:**
```bash
python scripts/deploy_ztp.py --subnet 192.168.1.0/24 --start-server
```

**Generated Files:**
- `ztp/dhcpd.conf` - DHCP server configuration
- `ztp/scripts/*_ztp.sh` - Device-specific ZTP scripts
- `ztp/configs/*.conf` - Device configurations

---

### manage_rbac.py

Configure Role-Based Access Control.

**Usage:**
```bash
python scripts/manage_rbac.py --action ACTION [OPTIONS]
```

**Actions:**
- `create` - Create new user account
- `deploy` - Deploy RBAC to device
- `template` - Generate RBAC template

**Options:**
- `--username STRING` - Username to create
- `--role STRING` - Role assignment (network_admin|network_operator|network_viewer)
- `--device STRING` - Target device IP
- `--output PATH` - Output directory

**Examples:**
```bash
# Create user
python scripts/manage_rbac.py --action create --username john --role network_operator

# Deploy to device
python scripts/manage_rbac.py --action deploy --device 192.168.1.11

# Generate template
python scripts/manage_rbac.py --action template --output rbac/
```

---

### validate_fabric.py

Validate fabric health and connectivity.

**Usage:**
```bash
python scripts/validate_fabric.py [OPTIONS]
```

**Options:**
- `-d, --devices STRING` - Device IPs (multiple allowed)
- `-u, --username STRING` - Device username
- `-p, --password` - Device password (prompted)
- `--report PATH` - Output report file

**Example:**
```bash
python scripts/validate_fabric.py \
    -d 192.168.1.11 \
    -d 192.168.1.21 \
    -u admin \
    --report validation.txt
```

**Validation Checks:**
1. BGP neighbor status
2. EVPN database entries
3. VXLAN VTEP connectivity
4. Interface operational status
5. Ping tests (optional)

---

### backup_configs.py

Backup device configurations.

**Usage:**
```bash
python scripts/backup_configs.py [OPTIONS]
```

**Options:**
- `-h, --host STRING` - Device IPs (multiple allowed)
- `-u, --username STRING` - Username
- `-p, --password` - Password (prompted)
- `--backup-dir PATH` - Backup directory (default: backups)

**Example:**
```bash
python scripts/backup_configs.py \
    -h 192.168.1.11 \
    -h 192.168.1.21 \
    -u admin \
    --backup-dir backups/$(date +%Y%m%d)
```

---

### connect_devices.py

Test device connectivity and gather facts.

**Usage:**
```bash
python scripts/connect_devices.py [OPTIONS]
```

**Options:**
- `-h, --host STRING` - Device IPs (multiple allowed)
- `-u, --username STRING` - Username
- `-p, --password` - Password (prompted)

**Example:**
```bash
python scripts/connect_devices.py \
    -h 192.168.1.11 \
    -h 192.168.1.21 \
    -u admin
```

---

## Python Library Functions

### FabricBuilder Class

```python
from scripts.configure_fabric import FabricBuilder

# Initialize
builder = FabricBuilder('configs/fabric.yaml')

# Generate IP assignments
assignments = builder.generate_underlay_ips()

# Generate VXLAN config
vxlan_config = builder.generate_vxlan_config(zone)

# Render configurations
spine_config = builder.render_spine_config(spine_data)
leaf_config = builder.render_leaf_config(leaf_data)
```

### ZTPServer Class

```python
from scripts.deploy_ztp import ZTPServer

# Initialize
ztp = ZTPServer()

# Generate DHCP configuration
dhcp_config = ztp.generate_dhcp_config(subnet, devices)

# Create ZTP script
script = ztp.create_ztp_script(device_name, config_url)

# Setup file server
ztp.setup_file_server()
```

### RBACManager Class

```python
from scripts.manage_rbac import RBACManager

# Initialize
rbac = RBACManager()

# Create user configuration
user_config = rbac.create_user(username, password, role)

# Apply zero trust policies
zt_config = rbac.apply_zero_trust_policies()

# Deploy to device
rbac.deploy_to_device(host, username, password, config)
```

### FabricValidator Class

```python
from scripts.validate_fabric import FabricValidator

# Initialize
validator = FabricValidator(device_list)

# Run validation
validator.run_validation(username, password)

# Display results
validator.display_results()

# Generate report
validator.generate_report('report.txt')
```

---

## REST API Integration

### Using PyEZ for Junos Automation

```python
from jnpr.junos import Device
from jnpr.junos.utils.config import Config

# Connect to device
device = Device(host='192.168.1.11', user='admin', password='password')
device.open()

# Load configuration
with Config(device) as cu:
    cu.load(path='config.conf', format='text')
    cu.commit(comment='Automated deployment')

# Get operational data
bgp_summary = device.rpc.get_bgp_summary_information()

device.close()
```

### NETCONF Operations

```python
from ncclient import manager

# Connect via NETCONF
with manager.connect(
    host='192.168.1.11',
    port=830,
    username='admin',
    password='password',
    hostkey_verify=False
) as m:
    # Get configuration
    config = m.get_config(source='running')
    
    # Edit configuration
    m.edit_config(target='candidate', config=new_config)
    m.commit()
```

---

## Error Codes

| Code | Description | Resolution |
|------|-------------|------------|
| E001 | Connection failed | Check network connectivity |
| E002 | Authentication failed | Verify credentials |
| E003 | Configuration syntax error | Review configuration file |
| E004 | Commit failed | Check device logs |
| E005 | Validation failed | Review validation report |

---

## Environment Variables

Set these for automated operations:

```bash
export JUNOS_USER="admin"
export JUNOS_PASSWORD="secure_password"
export JUNOS_SSH_KEY="/path/to/key"
export FABRIC_CONFIG="/path/to/fabric.yaml"
```

---

## Logging

All scripts support standard Python logging:

```python
import logging

# Set log level
logging.basicConfig(level=logging.DEBUG)

# Log to file
logging.basicConfig(
    filename='automation.log',
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
```

---

## Testing

Run unit tests:

```bash
# Install test dependencies
pip install pytest pytest-cov

# Run all tests
pytest tests/

# Run with coverage
pytest --cov=scripts tests/
```

Example test:

```python
def test_ip_generation():
    builder = FabricBuilder('test_config.yaml')
    ips = builder.generate_underlay_ips()
    assert len(ips['spines']) == 2
    assert len(ips['leafs']) == 4
```
