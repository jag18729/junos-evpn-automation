# Junos EVPN/VXLAN Automation Framework

[![Python](https://img.shields.io/badge/python-3.8%2B-blue)](https://www.python.org/)
[![Junos](https://img.shields.io/badge/Junos-18.1R1%2B-orange)](https://www.juniper.net/)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)
[![GitHub](https://img.shields.io/badge/GitHub-jag18729-black)](https://github.com/jag18729)
[![Automation](https://img.shields.io/badge/Automation-Ready-brightgreen)](https://github.com/jag18729/junos-evpn-automation)

> 🚀 **Production-ready automation framework for building modern Junos EVPN/VXLAN data center fabrics with zero-touch provisioning, RBAC, and zero-trust security**

---

## 📊 Architecture Overview

```
                        🌐 EVPN/VXLAN Fabric Architecture
    
    ┌──────────────────────────────────────────────────────────────────┐
    │                         Management Network                        │
    │                         192.168.1.0/24                           │
    └────────────┬──────────────────────────────────┬──────────────────┘
                 │                                  │
         ┌───────▼────────┐                ┌───────▼────────┐
         │   SPINE-1      │                │   SPINE-2      │
         │  BGP RR        │◄──────────────►│  BGP RR        │
         │  Lo: .1/32     │     eBGP        │  Lo: .2/32     │
         └────┬──────┬────┘   Underlay     └────┬──────┬────┘
              │      │                           │      │
         ┌────┼──────┼──────────────────────────┼──────┼────┐
         │    │      │         Full Mesh        │      │    │
         │    │      └───────────┬──────────────┘      │    │
         │    │                  │                     │    │
         │    ▼                  ▼                     ▼    │
    ┌────┴────────┐        ┌──────────┐        ┌──────────┴───┐
    │   LEAF-1    │        │  LEAF-2  │        │   LEAF-3     │
    │  VTEP       │◄──────►│  VTEP    │◄──────►│  VTEP        │
    │  Lo: .11/32 │ VXLAN  │ Lo:.12/32│ VXLAN  │  Lo: .13/32  │
    └─────┬───────┘ Tunnel └────┬─────┘ Tunnel └──────┬───────┘
          │                      │                      │
    ┌─────▼───────────────▼──────────────▼─────────────▼─────┐
    │     VNI 10100    │    VNI 10200    │    VNI 10300      │
    │   Production     │   Development   │      DMZ          │
    │  172.16.0.0/24   │  172.17.0.0/24  │  172.18.0.0/24    │
    └──────────────────┴──────────────────┴──────────────────┘
```

---

## ✨ Key Features

<table>
<tr>
<td width="50%">

### 🔧 **Automation**
- **Zero-Touch Provisioning** - Factory to production
- **Template-driven** - Jinja2 configuration templates
- **Parallel execution** - Multi-threaded validation
- **Idempotent operations** - Safe to run multiple times

</td>
<td width="50%">

### 🔐 **Security**
- **Zero Trust by default** - Micro-segmentation
- **RBAC templates** - Three-tier access control
- **Audit logging** - Complete command tracking
- **SSH hardening** - Rate limiting & protection

</td>
</tr>
<tr>
<td width="50%">

### 📈 **Scalability**
- **2 to 200+ devices** - Same configuration model
- **Multi-site ready** - DCI support built-in
- **Modular design** - Add features easily
- **YAML-driven** - Simple configuration files

</td>
<td width="50%">

### 🎯 **Validation**
- **Health checks** - BGP, EVPN, VXLAN status
- **Automated testing** - Continuous validation
- **Rich reporting** - Visual console output
- **Export ready** - JSON/CSV reports

</td>
</tr>
</table>

---

## 🚀 Quick Start Guide

### Prerequisites Check

```bash
# Check Python version
python3 --version  # Should be 3.8+

# Check network connectivity
ping 192.168.1.11  # Your first spine
```

### 1️⃣ **Installation**

```bash
# Clone repository
git clone https://github.com/jag18729/junos-evpn-automation.git
cd junos-evpn-automation

# Run automated setup
chmod +x setup.sh
./setup.sh

# Activate environment
source venv/bin/activate
```

### 2️⃣ **Configuration**

Edit `configs/fabric.yaml`:

```yaml
fabric:
  name: "DC1"
  asn: 65000
  underlay:
    ipv4_pool: "10.0.0.0/24"
    loopback_pool: "192.168.0.0/24"
```

### 3️⃣ **Generate Configs**

```bash
# Preview configurations
python scripts/configure_fabric.py --dry-run

# Generate actual configs
python scripts/configure_fabric.py --config configs/fabric.yaml
```

### 4️⃣ **Deploy with ZTP**

```bash
# Start ZTP server
python scripts/deploy_ztp.py --subnet 192.168.1.0/24 --start-server
```

### 5️⃣ **Validate Deployment**

```bash
# Check fabric health
python scripts/validate_fabric.py -d 192.168.1.11 -d 192.168.1.21 -u admin
```

---

## 📁 Project Structure

```
junos-evpn-automation/
│
├── 📂 configs/                 # Configuration files
│   ├── 📄 fabric.yaml         # Main fabric definition
│   ├── 📄 ztp.yaml           # ZTP server settings
│   └── 📂 generated/         # Auto-generated configs
│
├── 📂 scripts/                 # Automation scripts
│   ├── 🐍 configure_fabric.py # Generate configurations
│   ├── 🐍 deploy_ztp.py      # ZTP deployment
│   ├── 🐍 manage_rbac.py     # RBAC management
│   ├── 🐍 validate_fabric.py # Health validation
│   ├── 🐍 backup_configs.py  # Configuration backup
│   └── 🐍 connect_devices.py # Connection testing
│
├── 📂 templates/              # Jinja2 templates
│   ├── 📄 spine.j2           # Spine configuration
│   └── 📄 leaf.j2            # Leaf configuration
│
├── 📂 examples/               # Example configurations
│   ├── 📄 small_fabric.yaml  # 2x2 lab setup
│   └── 🐍 quick_vxlan.py    # Quick VXLAN script
│
└── 📂 ztp/                    # ZTP server files
    ├── 📂 configs/           # Device configs
    ├── 📂 scripts/           # ZTP scripts
    └── 📂 images/            # Junos images
```

---

## 🛠️ Core Components

### **1. Fabric Configuration Generator**

<details>
<summary>📝 <b>configure_fabric.py</b> - Click to expand</summary>

Automatically generates complete spine and leaf configurations:

```bash
python scripts/configure_fabric.py --config configs/fabric.yaml
```

**Features:**
- IP address calculation
- BGP peer generation
- VXLAN VNI mapping
- Zero-trust zone creation

**Output:**
```
✓ Generated config for spine1
✓ Generated config for spine2
✓ Generated config for leaf1
✓ Generated config for leaf2
```

</details>

### **2. Zero Touch Provisioning**

<details>
<summary>🚀 <b>deploy_ztp.py</b> - Click to expand</summary>

Automated device provisioning from factory default:

```bash
python scripts/deploy_ztp.py --subnet 192.168.1.0/24 --start-server
```

**Process Flow:**
```
Factory Device → DHCP Discovery → Config Download → Auto Configuration → Production Ready
```

**Features:**
- DHCP option 150 support
- HTTP file server
- Phone-home capability
- Progress tracking

</details>

### **3. RBAC Management**

<details>
<summary>🔐 <b>manage_rbac.py</b> - Click to expand</summary>

Role-based access control with three tiers:

```bash
# Create user
python scripts/manage_rbac.py --action create --username john --role network_operator

# Deploy to device
python scripts/manage_rbac.py --action deploy --device 192.168.1.11
```

**Built-in Roles:**

| Role | Permissions | Use Case |
|------|------------|----------|
| `network_admin` | Full access | Configuration changes |
| `network_operator` | Operational | Troubleshooting |
| `network_viewer` | Read-only | Monitoring |

</details>

### **4. Fabric Validation**

<details>
<summary>✅ <b>validate_fabric.py</b> - Click to expand</summary>

Comprehensive health checks across the fabric:

```bash
python scripts/validate_fabric.py -d 192.168.1.11 -d 192.168.1.21 -u admin
```

**Validation Checks:**
- ✅ BGP neighbor status
- ✅ EVPN database entries
- ✅ VXLAN VTEP connectivity
- ✅ Interface status
- ✅ End-to-end reachability

**Sample Output:**
```
╭─────────────── BGP Neighbor Status ───────────────╮
│ Device         │ Neighbor      │ Status          │
├────────────────┼───────────────┼─────────────────┤
│ 192.168.1.11   │ 10.0.0.2      │ ✅ Established  │
│ 192.168.1.11   │ 10.0.0.4      │ ✅ Established  │
╰────────────────┴───────────────┴─────────────────╯
```

</details>

---

## 🔍 Configuration Examples

### Basic VXLAN Setup

```junos
vlans {
    VLAN100 {
        vlan-id 100;
        vxlan {
            vni 10100;
        }
    }
}

protocols {
    evpn {
        encapsulation vxlan;
        extended-vni-list all;
    }
}
```

### Zero Trust Zone

```junos
firewall {
    family ethernet-switching {
        filter PRODUCTION_FILTER {
            term ALLOW_SAME_ZONE {
                from {
                    source-address 172.16.0.0/24;
                    destination-address 172.16.0.0/24;
                }
                then accept;
            }
            term DENY_CROSS_ZONE {
                then {
                    log;
                    reject;
                }
            }
        }
    }
}
```

---

## 📊 Monitoring & Troubleshooting

### Useful Commands

```bash
# Check EVPN database
show evpn database

# Verify VXLAN tunnels
show ethernet-switching vxlan-tunnel-end-point remote

# BGP status
show bgp summary

# MAC table
show evpn mac-table
```

### Common Issues & Solutions

| Issue | Solution |
|-------|----------|
| 🔴 **VTEP not forming** | Check loopback reachability: `ping 192.168.0.x routing-instance underlay` |
| 🔴 **No MAC learning** | Verify EVPN sessions: `show bgp neighbor` |
| 🔴 **Traffic dropped** | Check VNI mappings: `show vlans extensive` |
| 🔴 **BGP down** | Verify underlay: `show route protocol bgp` |

---

## 🤝 Contributing

We welcome contributions! Please see our contributing guidelines:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📚 Additional Resources

- 📖 [Juniper EVPN Documentation](https://www.juniper.net/documentation/en_US/junos/topics/topic-map/evpn-vxlan-overlay.html)
- 📖 [VXLAN RFC 7348](https://tools.ietf.org/html/rfc7348)
- 📖 [BGP EVPN RFC 7432](https://tools.ietf.org/html/rfc7432)
- 📖 [PyEZ Documentation](https://junos-pyez.readthedocs.io/)

---

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 👨‍💻 Author

**jag18729**
- GitHub: [@jag18729](https://github.com/jag18729)
- Project: [junos-evpn-automation](https://github.com/jag18729/junos-evpn-automation)

---

## ⭐ Show Your Support

Give a ⭐️ if this project helped you!

---

<div align="center">
  
**[⬆ Back to Top](#junos-evpnvxlan-automation-framework)**

</div>
